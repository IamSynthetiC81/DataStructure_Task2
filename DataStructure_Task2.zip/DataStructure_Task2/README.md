# Δομές Δεδομένων - Άσκηση 2

## Βοηθητικές διεπαφές.
- [Στατιστικά εργασίας](src/Statistics.html) : Κρατάει στατιστικά σε σχέση με τη διεργασία.
- [Μέθοδοι δέντρων](src/Operations.md#Operations) : Η διεπαφή αυτή κρατάει τις διεργασίες των δέντρων.
    - [Μέθοδοι Δυαδικού δέντρου](src/Operations.md#BSTOperations) : Κρατάει τις μεθόδους για ένα δυαδικό δέντρο.
    - [Μέθοδοι Λίστας Προτεραιότητας](src/Operations.md#HeapOperations) :Κρατάει τις μεθόδους για μία λίστα προτεραιότητας.

---

##  Δυαδικό Δέντρο

Οι βασικές διεργασίες που διέπουν το δυαδικό δέντρο είναι:
1. Εισαγωγή δεδομένων στον πίνακα με τη μέθοδο `Push`.
2. Αναζήτηση στοιχείου στον πίνακα με τη μέθοδο `Search`.
3. Διαγραφή στοιχείου στον πίνακα με τη μέθοδο `Pull`

- ### Εισαγωγή δεδομένων
  - H μέθοδος `Push` δρά σαν <i>βιτρίνα</i> για την εισαγωγή των στοιχείων στον πίνακα. Η μέθοδος μέσα απο την οποία εκτελείται η δράση είναι η `Add`.
  
<table style="width: 90%; margin: auto">
  <tr>
    <th>Υλοποίηση με πίνακα</th>
    <th>Υλοποίηση με δυναμική μνήμη</th>
  </tr>
  <tr>
    <td>
      Ξεκινάμε βλέποντας εάν το δέντρο είναι άδειο. Αν είναι, τότε εισάγουμε τον νέο στοιχείο στον πίνακα 
      δεδομένων με την εντολή <code>Value(Avail, value)</code>, η οποία είναι εντολή Setter για το Key της θέσης Avail.
      Όταν ο πίνακας δεν είναι άδειος, προσπελάζουμε τον πίνακα μέχρι να φτάσουμε στη σωστή κενή θέση, όπου
      εισάγουμε την τιμή, εισάγουμε τον πατέρα, και <i>φτιάχνουμε</i> τον δείκτη <code>Avail</code>, ο οποίος δείχνει στο 
      αμέσως επόμενο άδειο κελί του πίνακα.
    </td> 
    <td>  H <code>Insert</code> εισάγει τα δεδομένα αναδρομικά. Εάν 
          η εισαγόμενη τιμή είναι μικρότερη απο το κλειδί του Root, θέτουμε τον αριστερό κόμβο να είναι ίσος με
          το αποτέλεσμα της μεθόδου αυτής. Αν το κλειδί είναι μεγαλύτερο κάνουμε το αντίστοιχο για τον δεξί κόμβο.
          Αν ο κόμβος στον οποίο κλήθηκε η μέθοδος είναι <code>null</code>, τότε επιστρέφει έναν καινούργιο κόμβο με την
          εισαγόμενη τιμή, ο οποίος ανατίθεται στον σωστό κόμβο απο την προηγούμενη αναδρομή.
    </td> 
  </tr> 
</table>



- ### Διαγραφή δεδομένων

  Οι υλοποιήσεις είναι ίδιες, οπότε παρουσιάζονται σαν μία. 

  - Η μέθοδος `Pull` δρά και πάλι σαν <i>βιτρίνα</i> για τη διαγραφή των στοιχείων από τον πίνακα. Η μέθοδος μέσα απο την οποία εκτελείται η δράση είναι η `Remove`.
  - Ξεκινάμε προσπελάζοντας το δέντρο μέχρι να φτάσουμε στην κατάλληλη θέση. Για την προσπέλαση αρκεί να τρέξουμε 
  την μέθοδο για τον δεξί κόμβο εαν η τιμή που διαγράφουμε είναι μεγαλύτερη απο αυτήν του κόμβου, και τον αριστερό 
  εάν είναι μικρότερη (Εδώ κάνουμε το πολύ 2 συγκρίσεις). Αν η τιμή δεν είναι ούτε μικρότερη, και ούτε μεγαλύτερη,
  θα είναι ίση (Δε γίνεται σύγκριση) και έχουμε φτάσει στον κόμβο που αναζητούσαμε. Εκεί αντικαθιστούμε το κλειδί του 
  με το μικρότερο παιδί του δεξιού κόμβου με τη χρήση της μεθόδου `minValue`.
  Έπειτα διαγράφουμε το μικρότερο αυτό παιδί καλώντας αναδρομικά τη `Remove` για την τιμή αυτή.
    
- ### Αναζήτηση στοιχείου
  
  Οι υλοποιήσεις είναι ίδιες, οπότε παρουσιάζονται και πάλι σαν μία.

  - Η μέθοδος `Search` αρχίζει απο του Root του δέντρου, και προσπελάζει το δέντρο παίρνοντας το δεξί, ή
το αριστερό παιδί του κόμβου, ανάλογα την τιμή του (Κάνουμε και πάλι το πολύ 2 συγκρίσεις). Αν η τιμή δεν είναι μεγαλύτερη, και 
  ούτε και μικρότερη, τότε είναι ίση με την τιμή που ψάχνουμε, και επιστρέφει τον δείκτη του στοιχείου στον πίνακα. 
  
## Λίστα Προτεραιότητας 

Οι βασικές διεργασίες που διέπουν της λίστας προτεραιότητας είναι:
1. Εισαγωγή δεδομένων στον πίνακα με τη μέθοδο `Push`.
1. Εισαγωγή λίστας δεδομένων στον πίνακα με τη μέθοδο `Push`.
1. Εξαγωγή μεγίστου στοιχείου απο τον πίνακα με τη μέθοδο `Pull`.

- ### Εισαγωγή δεδομένων ένα-ένα 

  - H μέθοδος `Push` δρά σαν ____ για την εισαγωγή των στοιχείων στον πίνακα. 
    Η μέθοδος μέσα απο την οποία εκτελείται η δράση είναι η `Insert`.
  - Ξεκινάμε ελέγχοντας εάν το δέντρο περιέχει στοιχεία. Αν όχι, εισάγουμε το στοιχείο στο Root, διαφορετικά βρήσκουμε
  τον <i>δεξιότερο</i> κόμβο μέσω της `getRightMostParentNode` και εισάγουμε τα
  δεδομένα σαν παιδί του. Τέλος, εκτελούμε ένα `Bottom-Up Sort`.
    
- ### Εισαγωγή λίστας δεδομένων

  <table style="width: 90%; margin: auto">
  <tr>
    <th>Υλοποίηση με πίνακα</th>
    <th>Υλοποίηση με δυναμική μνήμη</th>
  </tr>
  <tr>
    <td>
      Η μέθοδος <a href="src/Operations.md#Push%20Array">Push</a> καλεί την <code>BuildHeap</code> επάνω στον
      πίνακα, η οποία μέθοδος καλέι την <code>Hipify</code>, όπως συζητήθηκε στο φροντιστήριο.
    </td> 
    <td>  
      Η μέθοδος <a href="src/Operations.md#Push%20Array">Push</a> πρώτα φτιάχνει έναν πίνακα απο <code>Node</code>
      με τις ανάλογες τιμές απο τον εισαγόμενο πίνακα δεδομένον. Έπειτα αναθέτει στον κάθε κόμβο με <code>index</code>
      παιδιά, θέτοντας σαν αριστερό παιδί τον κόμβο που βρίσκεται στο σημείο <math>\left (2\cdot index \right ) + 1</math>
      και δεξί τον κόμβο στο <math>\left (2\cdot index \right ) + 2</math>. η διαδικασία είναι ίδια με αυτήν 
      τις υλοποίησης του πίνακα, και με αυτήν που συζητήθηκε στο φροντιστήριο.
    </td> 
  </tr> 
  </table>

- ### Εξαγωγή μεγίστου στοιχείου

<table style="width: 90%; margin: auto">
  <tr>
    <th>Υλοποίηση με πίνακα</th>
    <th>Υλοποίηση με δυναμική μνήμη</th>
  </tr>
  <tr>
    <td>
      Η μέθοδος <code>Pull</code> αποθηκεύει το κλειδί του <code>Root</code>
      και το αντικαθιστά με το κλειδί του κόμβου που βρίσκεται στην θέση 
      <code>NumberOfElements</code>, βάζοντας παράλληλα
      στον τελευταίο κόμβο την τιμή -1 για να τον μαρκάρει σαν κενό. Τέλος, καλεί την <code>SiftDown</code>
      και κάνει sort τον πίνακα.
    </td> 
    <td>
      Η μέθοδος <code>Pull</code> αποθηκεύει το κλειδί του <code>Root</code>
      ,το αντικαθιστά με το κλειδί του κόμβου που επιστρέφει η μέθοδος <code>getRightMostParentNode()</code> και
      διαγράφει τον κόμβο. Τέλος, καλεί την <code>SiftDown</code>
      και κάνει sort τον πίνακα.
    </td> 
  </tr> 
  </table>

---
 Τα τελικά δεδομένα είναι τα εξής :

<style type="text/css">
.tg  {border-collapse:collapse;border-color:#ccc;border-spacing:0;margin:0px auto;}
.tg td{background-color:#fff;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;overflow:hidden;padding:6px 0px;word-break:normal;}
.tg th{background-color:#f0f0f0;border-color:#ccc;border-style:solid;border-width:1px;color:#333;
  font-family:Arial, sans-serif;font-size:14px;font-weight:normal;overflow:hidden;padding:6px 0px;word-break:normal;}
.tg .tg-wp8o{border-color:#000000;text-align:center;vertical-align:top}
.tg .tg-s1wl{border-color:#333333;font-family:"Times New Roman", Times, serif !important;font-weight:bold;position:-webkit-sticky;
  position:sticky;text-align:center;top:-1px;vertical-align:top;will-change:transform}
.tg .tg-sf4m{border-color:#333333;font-family:"Times New Roman", Times, serif !important;position:-webkit-sticky;position:sticky;
  text-align:center;top:-1px;vertical-align:top;will-change:transform}
.tg .tg-m2ib{border-color:#333333;font-family:"Times New Roman", Times, serif !important;text-align:center;vertical-align:top}
.tg .tg-7qdp{border-color:#333333;font-family:"Times New Roman", Times, serif !important;text-align:center;vertical-align:middle}
@media screen and (max-width: 767px) {.tg {width: auto !important;}.tg col {width: auto !important;}.tg-wrap {overflow-x: auto;-webkit-overflow-scrolling: touch;margin: auto 0px;}}</style>
<div class="tg-wrap"><table class="tg" style="table-layout: fixed; width: fit-content; margin: auto">
<colgroup>
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
<col style="width: 82px">
</colgroup>
<thead>
  <tr>
    <th class="tg-s1wl" colspan="8">Binary Search Tree</th>
    <th class="tg-sf4m" colspan="12">Priority Queue</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td class="tg-m2ib" colspan="4">Array Implementation</td>
    <td class="tg-m2ib" colspan="4">Dynamic Implementation</td>
    <td class="tg-m2ib" colspan="6">Array Implementation</td>
    <td class="tg-m2ib" colspan="6">Dynamic Implementation</td>
  </tr>
  <tr>
    <td class="tg-7qdp" colspan="2">Push</td>
    <td class="tg-7qdp" colspan="2">Pull</td>
    <td class="tg-7qdp" colspan="2">Push</td>
    <td class="tg-7qdp" colspan="2">Pull</td>
    <td class="tg-7qdp" colspan="2">Push</td>
    <td class="tg-7qdp" colspan="2">Push Array</td>
    <td class="tg-7qdp" colspan="2">Pull</td>
    <td class="tg-7qdp" colspan="2">Push</td>
    <td class="tg-7qdp" colspan="2">Push Array</td>
    <td class="tg-7qdp" colspan="2">Pull</td>
  </tr>
  <tr>
    <td class="tg-m2ib">Comparisons</td>
    <td class="tg-m2ib">Time</td>
    <td class="tg-m2ib">Comparisons</td>
    <td class="tg-m2ib">Time</td>
    <td class="tg-m2ib">Comparisons</td>
    <td class="tg-m2ib">Time</td>
    <td class="tg-m2ib">Comparisons</td>
    <td class="tg-m2ib">Time</td>
    <td class="tg-m2ib">Comparisons</td>
    <td class="tg-m2ib">Time</td>
    <td class="tg-m2ib">Comparisons</td>
    <td class="tg-m2ib">Time</td>
    <td class="tg-m2ib">Comparisons</td>
    <td class="tg-m2ib">Time</td>
    <td class="tg-m2ib">Comparisons</td>
    <td class="tg-m2ib">Time</td>
    <td class="tg-m2ib">Comparisons</td>
    <td class="tg-m2ib">Time</td>
    <td class="tg-m2ib">Comparisons</td>
    <td class="tg-m2ib">Time</td>
  </tr>
  <tr>
    <td class="tg-wp8o">39.7</td>
    <td class="tg-wp8o">203.3 ms</td>
    <td class="tg-wp8o">41.7</td>
    <td class="tg-wp8o">1.16 ms</td>
    <td class="tg-wp8o">25.7</td>
    <td class="tg-wp8o">217.1 ms</td>
    <td class="tg-wp8o">40.3</td>
    <td class="tg-wp8o">0.9 ms</td>
    <td class="tg-wp8o">2</td>
    <td class="tg-wp8o">240.8 ms</td>
    <td class="tg-wp8o">2.48</td>
    <td class="tg-wp8o">0 ns</td>
    <td class="tg-wp8o"> 37.8</td>
    <td class="tg-wp8o">0 ns</td>
    <td class="tg-wp8o">2</td>
    <td class="tg-wp8o">178.9 ms</td>
    <td class="tg-wp8o">2</td>
    <td class="tg-wp8o">71.1 ms</td>
    <td class="tg-wp8o">39.5</td>
    <td class="tg-wp8o">0 ns</td>
  </tr>
</tbody>
</table></div>

---

## Σχόλια

### Δυαδικό δέντρο
  Οι μέθοδοι και τα αποτελέσματα διαφέρουν ελάχιστα απο υλοποίηση σε υλοποίηση. Μονάχα η μέθοδος
  `push` διαφέρει στο οτι η υλοποίησή της είναι πιο εύκολη και πιο αποδοτική στην δυναμική υλοποίηση.

### Λίστα προτεραιότητας
  Οι μέθοδοι και τα αποτελέσματα διαφέρουν και πάλι ελάχιστα απο υλοποίηση σε υλοποίηση. Η κατασκευή του πίνακα
  παίρνει πολύ περισσότερο χρόνο για μια δυναμική κατασκευή, αλλά ο κώδικας της είναι μή αποδοτικός και θα μπορούσε 
  να γραφτεί καλύτερα, και να αποφέρει συμπαντικά κέρδη.  

Όσον αφορά τα αποτελέσματα, όλα ήταν αναμενόμενα.
1. Τα `Push` & `Pull` των δυαδικών δέντρον είναι πολύ κοντά στο <math>log(log_{2}N)</math>
2. Τα `Push` & `PushArray` των λιστών προτεραιότητας είναι και εκείνα ανάλογα με το <math>O\left(1\right)
3. Τα `Pull` των λιστών προτεραιότητας εκείνα ανάλογα του <math>log(log_{2}N)</math>.


