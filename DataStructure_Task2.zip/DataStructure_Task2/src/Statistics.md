# Στατιστικά

Κρατάει στατιστικά για τις μεθόδους του project.

- Οι μέθοδοι είναι οι εξής :
    - **`Start()`** : Αποθηκεύει τον χρόνο κλήσης μέσο του Object `Instant`.
    - **`End()`** : Μετράει τη διάρκεια απο τον χρόνο κλήσης της **`Start`** και 
      τον χρόνο κλήσης αυτής της μεθόδου.
    - **`Increment()`** : αυξάνει το `Counter` κατά ένα.
    - **`Increment(int increment)`** : αυξάνει το `Counter` κατά `increment`.
    - **`Reset()`** : Επαναφέρει το `Counter` στο 0.
    - **`getCounter()`** : Επιστρέφει τον τρέχοντα `Counter`.
    - **`getDuration()`** : Επιστρέφει την διάρκεια ανάμεσα στην κλήση της
      `Start` & `End`.
      
Οι`Start` & `End` καλούνται στην αρχή και τέλος της μεθόδους που θέλουμε να μετρήσουμε. Και
έπειτα απο το πέρας της μεθόδου, και αφού έχουμε πάρει τα στατιστικά, πρέπει να καλέσουμε
την `Reset` για να θέσουμε το `Counter` πίσω στο 0.



Οι μέθοδοι διέπονται απο τη διεπαφή [StatisticsInterface](Statistics/StatisticsInterface.java) 
και υλοποιούνται απο την κλάση [Statistics](Statistics/Statistics.java).

Οι υπόλοιπες κλάσεις λοιπών για να χρησιμοποιήσουν τα στατιστικά στο project πρέπει να
κάνουν implement την διεπαφή [StatisticsInterface](Statistics/StatisticsInterface.java).


