package src.PriorityQueue.DynamicImplementation;

import src.Interfaces.HeapOperations;
import src.Interfaces.Operations;
import src.Statistics.StatisticsInterface;

/**
 * This class implements a priority queue using a Max Heap.
 * TODO: if there is enough time, implement this using Generics and Comparable.
 */
public class PQ_DynamicImplementation implements StatisticsInterface, Operations , HeapOperations {
    /** Root of the heap. */
    Node Root;
    /** The number of elements in the queue. */
    private int NumberOfNodes;
    
    /**
     * A Priority Queue implementation using a Max Heap.
     *     <li><b>Time Complexity:</b> O(log n)
     *     <li><b>Space Complexity:</b> O(n)
     *     <li><b>Memory Complexity:</b> O(n)
     *     <li><b>Stability:</b> Unstable
     *     <li><b>Method:</b> Dynamic Implementation
     */
    public PQ_DynamicImplementation() {
        Root = null;
        NumberOfNodes = 0;
    }
    
    /**
     * Goes through the tree and asserts whether the heap is valid.
     * @param node The node to start from.
     * @return True if the heap is valid, false otherwise.
     */
    boolean isPQ(Node node){
        /*  if the left child's key is greater than the parent's key
            or if the right child's key is greater than the parent's key
            then the heap is not valid  */
        
        if (node == null) {                                                                 // If the node is null, the heap is valid.
            return true;                                                                    // Return true.
        }
        if(node.getLeft() != null && node.getLeft().getKey() > node.getKey()){
            return false;
        }
        if(node.getRight() != null && node.getRight().getKey() > node.getKey()){
            return false;
        }
        return isPQ(node.getLeft()) && isPQ(node.getRight());
    }
    
    /**
     * Inserts the given key into the heap.
     * <li><b>Time Complexity:</b> O(log n)
     * <li><b>Space Complexity:</b> O(1)
     * <li><b>Memory Complexity:</b> O(1)
     * @param data The key to insert.
     */
    private void Insert(int data) {
        if (NumberOfNodes == 0) {                                                           // If the heap is empty, insert the node as the root.
            Root = new Node(data);                                                          // Create a new node with the given data.
            NumberOfNodes++;                                                                // Increment the number of nodes.
            return;                                                                         // Return.
        }

        Node parentNode = getRightMostParentNode(NumberOfNodes + 1);           // Get the parent node of the new node.
        Node newNode = new Node(data, parentNode);                                          // Create a new node with the given data and parent node.

        switch (parentNode.getChildCount()) {                                               // Switch on the number of children the parent node has.
            case 0:                                                                         // If the parent node has no children, set the new node as the left child.
                parentNode.setLeft(newNode);
                NumberOfNodes++;
                break;
            case 1:                                                                         // If the parent node has one child, set the new node as the right child.
                parentNode.setRight(newNode);
                NumberOfNodes++;
                break;
        }
        Sort(newNode);                                                                      // Sort the new node.
    }
    
    /**
     * Performs a Bottom-Up sort on the heap.
     * <li><b>Time Complexity:</b> O(log n)
     * <li><b>Space Complexity:</b> O(1)
     * <li><b>Memory Complexity:</b> O(1)
     * @param node The node to start from.
     */
    private void Sort(Node node) {
        if (node == null)                                                                   // If the node is null, there is nothing to sort.
            return;

        Node parent = node.getParent();                                                     // Get the parent node.
        if (parent != null) {                                                               // If the parent node is not null,

            int ParentKey = parent.getKey();                                                // Get the parent node's key.
            int NodeKey = node.getKey();                                                    // Get the node's key.

            Increment();                                                                    // Increment the number of comparisons.
            if (ParentKey < NodeKey) {                                                      // If the parent node's key is less than the node's key,
                Swap(parent, node, ParentKey, NodeKey);                                     // Swap the parent node with the node.
                Sort(parent);                                                               // Sort the parent node.
            }
        }
    }
    
    /**
     * Performs a Top-Down sort on the heap.
     * <li><b>Time Complexity:</b> O(log n)
     * <li><b>Space Complexity:</b> O(1)
     * <li><b>Memory Complexity:</b> O(1)
     * @param node The node to start from.
     */
    private void SortDown(Node node) {
        if (node == null)                                                                   // If the node is null, there is nothing to sort.
            return;

        Node left = node.getLeft();                                                         // Get the left child node.
        Node right = node.getRight();                                                       // Get the right child node.
        int NodeKey = node.getKey();                                                        // Get the node's key.
        int LeftKey = (left != null) ? left.getKey() : -1;                                  // Get the left child node's key.
        int RightKey = (right != null) ? right.getKey() : -1;                               // Get the right child node's key.
        
        Increment(2);                                                                       // Increment the number of comparisons.
        
        Node max = (LeftKey > RightKey) ? left : right;                                     // Get the node with the largest key.
        if(max != null && NodeKey < max.getKey()) {                                         // If the node's key is less than the largest key,
            Swap(node, max, NodeKey, max.getKey());                                         // Swap the node with the largest key.
            SortDown(max);                                                                  // Sort the node with the largest key. (Recursive)
        }
    }
    
    /**
     * Swaps the keys of two nodes with the given keys.
     * @param node1 The first node.
     * @param node2 The second node.
     * @param key1 The first key to swap into the second node.
     * @param key2 The second key to swap into the first node.
     */
    private void Swap(Node node1, Node node2, int key1, int key2) {
        node1.setKey(key2);                                                                 // Set the first node's key to the second key.
        node2.setKey(key1);                                                                 // Set the second node's key to the first key.
    }
    
    /**
     * Performs a Bottom-Up sort on the heap..
     * <li><b>Time Complexity:</b> O(log n)
     * <li><b>Space Complexity:</b> O(1)
     * <li><b>Memory Complexity:</b> O(1)
     *
     * @param Nodes The nodes to sort.
     * @implNote The root node is the first node in the array.
     */
    public void Sort(Node[] Nodes) {
        int n = Nodes.length;                                                                // Get the number of nodes.
        
        // Build heap
        for (int i = n / 2 - 1; i >= 0; i--)                                                 // For each node in the array,
            Hipiefy(Nodes, n, i);                                                            // Heapify the node.
    }
    
    /**
     * Heapifies the array.
     * <p>
     *     The heap is built in bottom up manner.
     * </p>
     * <p>
     *      <b>Yes,</b> the name is a joke ...
     * </p>
     * @param Nodes The nodes to heapify.
     * @param numberOfNodes The number of nodes in the array.
     * @param index The index to start from.
     */
    void Hipiefy(Node[] Nodes, int numberOfNodes, int index) {
        int largest = index;                                                                 // Set the largest index to the current index.
        int l = 2 * index + 1;                                                               // Set the left index to the left child of the current index.
        int r = 2 * index + 2;                                                               // Set the right index to the right child of the current index.


        Increment(2);
        if (l < numberOfNodes && Nodes[l].getKey() > Nodes[largest].getKey())                // If the left node's key is greater than the largest node's key,
            largest = l;                                                                     // Set the largest index to the left node.

        if (r < numberOfNodes && Nodes[r].getKey() > Nodes[largest].getKey())                // If the right node's key is greater than the largest node's key,
            largest = r;                                                                     // Set the largest index to the right node.
        
        if (largest != index) {                                                              // If the largest index is not the current index,
            int swap = Nodes[index].getKey();                                                // Set the swap key to the current index's key.
            Nodes[index].setKey(Nodes[largest].getKey());                                    // Set the current index's key to the largest node's key.
            Nodes[largest].setKey(swap);                                                     // Set the largest node's key to the swap key.
            
            Hipiefy(Nodes, numberOfNodes, largest);                                          // Heapify the array from the largest index.
        }
    }
    
    /**
     * Returns the right most parent node of the given node.
     * @param numberOfNodes The number of nodes in the heap.
     * @return {@link Node} The right most parent node.
     */
    private Node getRightMostParentNode(int numberOfNodes) {
        if (numberOfNodes == 0 || numberOfNodes < 0) {                                       // If the number of nodes is 0 or less,
            return null;                                                                     // Return null.
        }
        Node current = Root;                                                                 // Set the current node to the root node.
        // binary of numberOfElements without leading zeros
        String asBinary = Integer.toBinaryString(numberOfNodes);                             // Set the binary string to the number of nodes in the heap.
        // iterate from 2nd bit up to second to last bit
        for (int currentPos = 1; currentPos < asBinary.length() - 1; currentPos++) {         // For each bit from the second to the second to last bit,
            if (asBinary.charAt(currentPos) == '0') {                                        // If the current bit is 0,
                current = current.getLeft();                                                 // Set the current node to the left child of the current node.
            } else {                                                                         // Else, if the current bit is 1,
                current = current.getRight();                                                // Set the current node to the right child of the current node.
            }
        }
        return current;                                                                      // Return the current node. The right most parent node.
    }
    
    /* Public Methods */
    
    /**
     * Adds the specified element to the queue.
     *
     * This method acts as a public Front for the method {@link #Insert(int)} for
     * easier implementation of the {@link src.Statistics.Statistics} functionality.
     *
     * @param key the value to add.
     */
    public void Push(int key) {
        statistics.Start();                                                                  // Start the statistics.
        
        Insert(key);                                                                         // Insert the key.
        
        statistics.End();                                                                    // End the statistics.
    }
    
    /**
     * Adds the specified elements to the queue.
     * @param keys the values to add.
     */
    public void Push(int[] keys) {
        statistics.Start();                                                                  // Start the statistics.
        
        Node[] Nodes = new Node[keys.length];                                                // Create an array of nodes.
        
        for (int i = 0; i < keys.length; i++)                                                // For each key,
            Nodes[i] = new Node(keys[i]);                                                    // Create a new node with the key.
        for(int i = 0 ; i < keys.length ; i++){                                              // For each node,
            if ((2 * i) + 1 < keys.length) Nodes[i].setLeft(Nodes[(2 * i)+ 1]);              // If the left index is valid, set the left child.
            if ((2 * i) + 2 < keys.length) Nodes[i].setRight(Nodes[2 * i + 2]);              // If the right index is valid, set the right child.
            
            /* the left and right index did not need to be the array equivalent of the nodes index,
                but mehhhh, it is done. */
        }
        
        Sort(Nodes);                                                                         // Sort the nodes.
        
        Root = Nodes[0];                                                                     // Set the root node.
        
        NumberOfNodes = keys.length;                                                         // Set the number of nodes.
        
        statistics.End();                                                                    // End the statistics.
    }
    
    /**
     * Returns the element at the head of the queue.
     * @return the element at the head of the queue.
     */
    public int Pull() {
        statistics.Start();                                                                  // Start the statistics.
        
        assert NumberOfNodes > 0 : "Heap is empty";                                          // Assert that the heap is not empty.
        int data = Root.getKey();                                                            // Get the data.
        
        Node lastNode = getRightMostParentNode(NumberOfNodes);                               // Get the last node.
        switch (lastNode.getChildCount()) {                                                  // Switch on the number of children.
            case 0:                                                                          // If there are no children,
                Root.setKey(lastNode.getKey());                                              // Set the root to the last node.
                lastNode = null;                                                             // Nullify the last node
                break;
            case 1:                                                                          // If there is one child,
                Root.setKey(lastNode.getLeft().getKey());                                    // Set the root to the left child.
                lastNode.setLeft(null);                                                      // Nullify the left child.
                break;
            case 2:
                Root.setKey(lastNode.getRight().getKey());                                   // Set the root to the right child.
                lastNode.setRight(null);                                                     // Nullify the right child.
                break;
        }
        SortDown(Root);                                                                      // Sort down the root.
        
        NumberOfNodes--;                                                                     // Decrement the number of nodes.
    
        statistics.End();                                                                    // End the statistics.
        
        return data;                                                                         // Return the data.
    }

    /**
     * Clears all the nodes from the heap.
     */
    public void Clear(){
        Root = null;
    }
    
}
