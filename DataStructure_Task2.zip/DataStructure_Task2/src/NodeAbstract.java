package src;

/**
 * Failed attempt to create an abstract class for nodes.
 *
 * Alas, there is no time.
 * TODO: Turn away from using {@link /src/PriorityQueue/
 */
public class NodeAbstract {

    private int Key;
    private NodeAbstract Left;
    private NodeAbstract Right;
    private NodeAbstract Parent;
    
    public NodeAbstract(int key) {
        this.Key = key;
        this.Left = null;
        this.Right = null;
        this.Parent = null;
    }
    
    public NodeAbstract(int key, NodeAbstract parent) {
        this.Key = key;
        this.Parent = parent;
        
        this.Left = null;
        this.Right = null;
    }
    
    public int getKey() {
        return this.Key;
    }
    
    public NodeAbstract getLeft() {
        return this.Left;
    }
    
    public NodeAbstract getRight() {
        return this.Right;
    }
    
    public NodeAbstract getParent() {
        return this.Parent;
    }
    
    public void setKey(int key) {
        this.Key = key;
    }
    
    public void setLeft(NodeAbstract left) {
        this.Left = left;
    }
    
    public void setRight(NodeAbstract right) {
        this.Right = right;
    }
    
    public void setParent(NodeAbstract parent) {
        this.Parent = parent;
    }
    
    public boolean isLeaf() {
        return this.Left == null && this.Right == null;
    }
    
    public int ChildrenNum() {
        int num = 0;
        if (this.Left != null)
            num++;
        if (this.Right != null)
            num++;
        return num;
    }
    
    public NodeAbstract getMinChild(){
        NodeAbstract min = this;
        if(this.Left != null)
            min = this.Left;
        if(this.Right != null) {
            if(min.getKey() > this.Right.getKey())
                min = this.Right;
        }
        return min;
    }
}
