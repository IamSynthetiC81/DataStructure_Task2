package src.PriorityQueue.ArrayImplementation;

import src.Interfaces.HeapOperations;
import src.Interfaces.Operations;
import src.Statistics.Statistics;
import src.Statistics.StatisticsInterface;

/** this is the implementation of the priority queue using an array
 * TODO: if there is enough time, implement this using Generics and Comparable.
 */
public class PQ_ArrayImplementation implements StatisticsInterface, Operations, HeapOperations {
    /** Index of the <i>Nodes Left Index</i> in the array.*/
    private static final int LEFT = 1;
    /** Index of the <i>Nodes Right Index</i> in the array.*/
    private static final int RIGHT = 2;
    /** the array that holds the tree.*/
    private int[] array;
    /** The numbers of elements into the array.*/
    private int NumberOfElements;
    /** The size of the array.*/
    private final int Size;
    
    public PQ_ArrayImplementation(int size) {
        Size = size;                                                                                       // the size of the array
        array = new int[size];                                                                             // the array that holds the tree

        for (int i = 0; i < size; i++) {                                                                   // initialize the array
                array[i] = -1;                                                                             // initialize the array
        }
        NumberOfElements = 0;                                                                              // the number of elements in the array
    }
    
    /**
     * Returns true if the node is a leaf.
     *
     * @param pos the position of the node.
     * @return true if the node is a leaf and false otherwise.
     */
    public boolean isLeaf(int pos) {
        return (pos >= NumberOfElements / 2) && (pos < NumberOfElements);
    }
    
    /**
     * Calculates the correct index for the left child of the node.
     *
     * @param pos the position of the node.
     * @return the index of the left child.
     */
    private int LeftChildPos(int pos) {
        if (2 * pos + 1 < Size)                                                                            // if the left child exists
            return (2 * pos) + 1;                                                                          // return the index of the left child
        else                                                                                               // otherwise
            return -1;                                                                                     // return -1 if the left child doesn't exist
    }
    
    /**
     * Calculates the correct index for the right child of the node.
     *
     * @param pos the position of the node.
     * @return the index of the right child.
     */
    private int RightChildPos(int pos) {
        if (2 * pos + 2 < Size)                                                                            // if the right child exists
            return (2 * pos) + 2;                                                                          // return the index of the right child
        else                                                                                               // if the right child doesn't exist
            return -1;                                                                                     // return -1
    }
    
    /**
     * Getter for the key of a node.
     *
     * @param pos the position of the node.
     * @return the key of the node.
     * @implNote calling this increments the counter of the {@link Statistics} object.
     */
    private int getKey(int pos) {
        return array[pos];                                                                                 // return the key of the node
    }
    
    /**
     * Setter for the key of a node.
     *
     * @param pos the position of the node.
     * @param key the key to set.
     */
    private void setKey(int pos, int key) {
        array[pos] = key;                                                                                  // set the key of the node
    }
    
    /**
     * Get the number of children of a <i>node</i>.
     *
     * @param pos the node
     * @return the number of children.
     */
    private int ChildrenNum(int pos) {
        int count = 0;                                                                                      // the number of children
        if (LeftChildPos(pos) != -1 && getKey(LeftChildPos(pos)) != -1)                                     // if the left child exists and is not empty
            count++;                                                                                        // increment the number of children
        if (RightChildPos(pos) != -1 && getKey(RightChildPos(pos)) != -1) count++;                          // if the right child exists and is not empty
        return count;                                                                                       // return the number of children
    }
    
    private int getMaxHeight() {
        return (int) (Math.log(Size) / Math.log(2));                                                        // return the maximum height of the tree
    }
    
    private int getHeight(int pos) {
        for (int i = 0; i < getMaxHeight(); i++) {                                                          // for each level
            if (pos >= Math.pow(2, i) - 1 && pos < Math.pow(2, i + 1) - 1)                                  // if the node is in the level
                return i;                                                                                   // return the level
        }
        return -1;                                                                                          // if the node is not in the tree
    }
    
    /**
     * Calculates the correct index for the in
     *
     * @param pos the position of the node.
     * @return the correct index.
     */
    private int getParentForNextRow(int pos) {
        int height = getHeight(pos);                                                                        // get the height of the node
        return (int) (Math.pow(2, height) - 1);                                                             // return the correct index
    }
    
    private void Insert(int pos, int data) {
        if (NumberOfElements == 0) {                                                                        // if the tree is empty
            setKey(0, data);                                                                            // set the key of the node
            NumberOfElements++;                                                                             // increment the number of elements
            return;                                                                                         // return
        }
        
        int NodePos = getRightMostParentNode(NumberOfElements + 1);                          // get the right most parent node
        
        switch (ChildrenNum(NodePos)) {                                                                     // switch on the number of children
            case 0:                                                                                         // if the node has no children
                setKey(LeftChildPos(NodePos), data);                                                        // set the key of the left child
                bubbleUp(LeftChildPos(NodePos));                                                            // bubble up the node
                break;
            case 1:                                                                                         // if the node has one child
                setKey(RightChildPos(NodePos), data);                                                       // set the key of the right child
                bubbleUp(RightChildPos(NodePos));                                                           // bubble up the node
                break;
        }
        NumberOfElements++;                                                                                 // increment the number of elements
    }
    
    void bubbleUp(int pos) {
        int parentIndex = (pos - 1) / 2;                                                                    // get the parent index
        int currentIndex = pos;                                                                             // get the current index
        int parentKey = getKey(parentIndex);                                                                // get the parent key
        int currentKey = getKey(currentIndex);                                                              // get the current key
    
        Increment();                                                                                        // increment the number of comparisons
        while (currentIndex > 0 && parentKey < currentKey) {                                                // while the current index is not the root and the parent key is less than the current key
            Increment();                                                                                    // increment the number of comparisons
            swap(currentIndex, parentIndex, currentKey, parentKey);                                         // swap the current key with the parent key
            currentIndex = parentIndex;                                                                     // set the current index to the parent index
            parentIndex = (parentIndex - 1) / 2;                                                            // set the parent index to the parent of the parent
            parentKey = getKey(parentIndex);                                                                // set the parent key to the parent key
            currentKey = getKey(currentIndex);                                                              // set the current key to the current key
        }
    }
    
    /**
     * Swaps the keys of the two nodes
     * @param pos1 the first node
     * @param pos2 the second node
     * @param pos1Key The key to swap into the second node.
     * @param pos2Key The key to swap into the first node.
     */
    void swap(int pos1, int pos2, int pos1Key, int pos2Key) {
        setKey(pos1, pos2Key);                                                                              // set the first node's key to the second node's key
        setKey(pos2, pos1Key);                                                                              // set the second node's key to the first node's key
    }
    
    /**
     * Gets the parent of the rightmost <i>node</i> using the method shown during the lessons.
     *
     * @return the parent of the rightmost <i>node</i>
     */
    private int getRightMostParentNode(int numberOfElements) {
        int current = 0;                                                                                    // set the current index to 0
        // binary of numberOfElements without leading zeros
        String asBinary = Integer.toBinaryString(numberOfElements);                                         // get the binary representation of the number of elements
        // iterate from 2nd bit up to second to last bit
        for (int currentPos = 1; currentPos < asBinary.length() - 1; currentPos++) {                        // for each bit from the second bit up to the second to last bit
            if (asBinary.charAt(currentPos) == '0') {                                                       // if the current bit is a 0
                current = LeftChildPos(current);                                                            // set the current index to the left child of the current index
            } else {                                                                                        // otherwise
                current = RightChildPos(current);                                                           // set the current index to the right child of the current index
            }
        }
        return current;                                                                                     // return the current index
    }
    
    /**
     * Builds the heap.
     *
     * <p>
     *      Yes, the name is a joke !
     * </p>
     */
    private void Hipiefy(int[] heap, int size, int index) {
        int largest = index;                                                                                // set the largest index to the current index
        int left = (2 * index) + 1;                                                                         // set the left index to the left child of the current index
        int right = ((2 * index) + 2);                                                                      // set the right index to the right child of the current index
        
        Increment(2);                                                                                       // increment the number of comparisons
        if (left < size && heap[left] > heap[largest])                                                      // if the left index is greater than the largest index
            largest = left;                                                                                 // set the largest index to the left index
        if (right < size && heap[right] > heap[largest])                                                    // if the right index is greater than the largest index
            largest = right;                                                                                // set the largest index to the right index
        
        if (largest != index) {                                                                             // if the largest index is not the current index
            swap(index, largest, heap[index], heap[largest]);                                               // swap the current index and the largest index
            Hipiefy(heap, size, largest);                                                                   // recursively call the method with the largest index
        }
    }
    
    private void buildHeap(int arr[], int size){
        
        int startIndex = (size / 2) -1 ;                                                                    // set the start index to the last parent index
        
        for(int i = startIndex; i >= 0; i--){                                                               // loop through the parent indices
            Hipiefy(arr, size, i);                                                                          // call the hipify method with the current index
        }
    }
    
    private void siftDown(int pos){
        assert pos >= 0 && pos < Size : "Position is out of range";                                         // assert the position is in range
        
        while (!isLeaf(pos)) {                                                                              // while the position is not a leaf
            int LeftChild = LeftChildPos(pos);                                                              // set the left child to the left child position
            Increment(2);                                                                                   // increment the number of comparisons
            if ((LeftChild < (NumberOfElements - 1)) && (getKey(LeftChild) < getKey(LeftChild + 1)))   // if the left child is less than the right child and the left child is less than the right child
                LeftChild++;                                                                                // set the left child to the right child
            if (getKey(pos)>= getKey(LeftChild))                                                            // if the current index is greater than the left child
                return;                                                                                     // return
            swap(pos, LeftChild, getKey(pos), getKey(LeftChild));                                           // swap the current index and the left child
            pos = LeftChild; // Move down                                                                   // set the position to the left child
        }
    }
    
    /**
     * Add a new value to the heap.
     * @param data the value to be added.
     */
    @Override
    public void Push(int data) {
        statistics.Start();                                                                                 // start the timer
        
        Insert(0, data);                                                                                // insert the value into the heap
        
        statistics.End();                                                                                   // end the timer
    }
    
    /**
     * Adds the specified values to the heap.
     * @param data the values to add.
     */
    @Override
    public void Push(int[] data) {
        NumberOfElements = data.length;                                                                     // set the number of elements to the length of the array
        System.arraycopy(data, 0, array, 0, data.length);                                     // copy the array into the heap
        
        buildHeap(array, Size);                                                                             // build the heap
    }
    
    /**
     * Remove the max value from the heap
     * @return the max value
     */
    @Override
    public int Pull() {
        statistics.Start();                                                                                 // start the timer
        
        int data = getKey(0);                                                                           // set the data to the root

        swap(0, --NumberOfElements, -1, array[NumberOfElements]);                              // swap the root with the last element
        if(NumberOfElements != 0)                                                                           // if the heap is not empty
            siftDown(0);                                                                                // sift down the root
        
        statistics.End();                                                                                   // end the timer
        
        return data;                                                                                        // return the data
    }
    
    /**
     * Asserts that the rules of the heap are respected.
     * @param index the index of the node to check.
     * @return true if the Priority Queue is valid, false otherwise.
     */
    boolean isPQ(int index) {
        if(index < 0 || index >= Size )                                                                     // if the index is out of bounds
            return true;                                                                                    // return true
        if ( LeftChildPos(index) != -1 && getKey(LeftChildPos(index)) > getKey(index) )                     // if the left child is greater than the parent
            return false;                                                                                   // return false
        if ( RightChildPos(index) != -1 && getKey(RightChildPos(index)) > getKey(index) )                   // if the right child is greater than the parent
            return false;                                                                                   // return false
        return isPQ(LeftChildPos(index)) && isPQ(RightChildPos(index));                                     // return the result of the left and right children
    }

    public void Clear(){
        array = new int[Size];                                                                              // the array that holds the tree

        for (int i = 0; i < Size; i++) {                                                                    // initialize the array
            array[i] = -1;                                                                                  // initialize the array
        }
        NumberOfElements = 0;                                                                               // the number of elements in the array
    }
    
}
