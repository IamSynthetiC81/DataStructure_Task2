package src.BinarySearchTree.DynamicImplementation;

import src.Interfaces.BSTOperations;
import src.NodeAbstract;
import src.Interfaces.Operations;
import src.Statistics.StatisticsInterface;

/**
 * This class represents a binary search tree.
 */
public class BST_DynamicImplementation implements StatisticsInterface, Operations , BSTOperations {
    /** The root of the tree. */
    NodeAbstract Root;
    /**
     * <li><b>Complexity</b>: O(log n)
     * <li><b>Time complexity</b>: O(log n)
     * <li><b>Space complexity</b>: O(log n)
     * <li><b>Worst case</b>: O(n)
     * <li><b>Average case</b>: O(log n)
     * <li><b>Best case</b>: O(log n)
     */
    public BST_DynamicImplementation() {
        Root = null;
    }
    
    /**
     * Tests whether the tree is constructed correctly.
     * @param root The node to start from.
     * @return True if the tree is correct, false otherwise.
     */
    @Override
    public boolean isBST(Object root){
        
        NodeAbstract node = (NodeAbstract) root;                                    // Cast the root to a node
        
        if (node == null) {                                                         // If the node is null
            return true;                                                            // Return true
        }
        if (node.getLeft() != null && node.getLeft().getKey() > node.getKey()) {    // If the left child is greater than the node
            return false;                                                           // Return false
        }
        if (node.getRight() != null && node.getRight().getKey() < node.getKey()) {  // If the right child is less than the node
            return false;                                                           // Return false
        }
        return isBST(node.getLeft()) && isBST(node.getRight());                     // Return the result of the left and right subtrees
    }
    
    /**
     * Inserts a node into the tree.
     *
     * @implNote This method is recursive. In extreme cases it can cause stack overflow
     *              unless the tree is balanced or the stack is increased significantly.
     *
     * @param node The node to insert.
     * @param value The value to insert.
     * @return The new root of the tree.
     */
    private NodeAbstract Insert(NodeAbstract node, int value){
        if (node == null) {                                                          // If the node is null
            return new NodeAbstract(value);                                          // Return a new node
        }
        Increment();                                                                 // Increment the number of comparisons
        
        int nodeInfo = node.getKey();                                                // Get the node's key
        
        if (value < nodeInfo) {                                                      // If the value is less than the node
            node.setLeft(Insert(node.getLeft(), value));                             // Set the left child to the result of inserting the value
            node.getLeft().setParent(node);                                          // Set the left child's parent to the node
        } else if (value > nodeInfo) {                                               // If the value is greater than the node
            node.setRight(Insert(node.getRight(), value));                           // Set the right child to the result of inserting the value
            node.getRight().setParent(node);                                         // Set the right child's parent to the node
        }
        return node;                                                                 // Return the node
    }
    
    /**
     * Return the minimum value in the tree.
     * @param node The node to start from.
     * @return The minimum value in the tree.
     */
    private NodeAbstract getMin(NodeAbstract node) {
        if (node.getLeft() == null) {                                                 // If the node has no left child
            return node;                                                              // Return the node
        }
        return getMin(node.getLeft());                                                // Return the result of getting the minimum value from the left child
    }
    
    /**
     * Removes the specified node from the tree.
     * @param node The node to remove the value from.
     * @param value The value to remove.
     * @return The new root of the tree.
     */
    private NodeAbstract RemoveNode(NodeAbstract node, int value) {
        if (node == null)                                                               // If the node is null
            return null;                                                                // Return null
        
        Increment();                                                                    // Increment the number of nodes
        if(value < node.getKey()) {                                                     // If the value is less than the node
            node.setLeft(RemoveNode(node.getLeft(), value));                            // Set the left child to the result of removing the value from the left child
        } else if(value > node.getKey()) {                                              // If the value is greater than the node
            Increment();                                                                // Increment the number of comparisons
            node.setRight(RemoveNode(node.getRight(), value));                          // Set the right child to the result of removing the value from the right child
        } else {                                                                        // If the value is equal to the node
            if(node.getLeft() == null)                                                  // If the node has no left child
                return node.getRight();                                                 // Return the right child
            else if(node.getRight() == null)                                            // If the node has no right child
                return node.getLeft();                                                  // Return the left child
            
            node.setKey(getMin(node.getRight()).getKey());                              // Set the node to the minimum value from the right child
            node.setRight(RemoveNode(node.getRight(), node.getKey()));                  // Set the right child to the result of removing the minimum value from the right child
        }
        return node;                                                                    // Return the node
    }
    
    /**
     * Searches for the specified value in the tree.
     * @param value the value to search for.
     * @return Returns the {@link NodeAbstract} containing the value if found, otherwise null.
     */
    public NodeAbstract Search(int value) {
        NodeAbstract current = Root;                                                    // Set the current node to the root
        while (current != null) {                                                       // While the current node is not null
            if (current.getKey() == value) {                                            // If the current node's key is equal to the value
                return current;                                                         // Return the current node
            } else if (current.getKey() < value) {                                      // If the current node's key is less than the value
                current = current.getRight();                                           // Set the current node to the right child
            } else {                                                                    // If the current node's key is greater than the value
                current = current.getLeft();                                            // Set the current node to the left child
            }
        }
        return null;                                                                    // Return null
    }
    
    /**
     * A <i>Front</i> for the {@link #Insert(NodeAbstract, int)} method. This helps the implementation
     * of the {@link src.Statistics.Statistics} functions.
     * @param value The value to insert.
     */
    public void Push(int value) {
        statistics.Start();                                                             // Start timer
        
        Root = Insert(Root, value);                                                     // Insert the value
        
        statistics.End();                                                               // End of Append
    }
    
    /**
     * Pulls the specified value from the tree.
     * @param value the value to pull.
     */
    public void Pull(int value){
        statistics.Start();                                                             // Start timer
        
        Root = RemoveNode(Root, value);                                                 // Remove the value
        
        statistics.End();                                                               // End of Delete
    }
    
}
