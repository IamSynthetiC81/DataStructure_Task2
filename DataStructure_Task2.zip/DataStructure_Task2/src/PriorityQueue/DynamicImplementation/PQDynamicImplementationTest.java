package src.PriorityQueue.DynamicImplementation;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import src.Files.FileOps;

import java.io.IOException;
import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ThreadLocalRandom;


import static org.junit.jupiter.api.Assertions.*;

class PQDynamicImplementationTest {
    
    /** Data for the heap to be tested on. */
    private final static int[] testArray = {10, 50, 60, 70, 100, 120, 55, 30, 40, 20};
    /** The result of the heap sort. */
    private final static int[] Result = {120, 100,70, 60, 55, 50, 40, 30, 20, 10};
    /** UUT Declaration. */
    PQ_DynamicImplementation UUT;

    @BeforeEach
    void setUp() {
        UUT = new PQ_DynamicImplementation();
    }
    
    @AfterEach
    void tearDown() {
        UUT = null;
    }
    
    @Test
    @Tag("Basic Functionality")
    @DisplayName("Test pushing a predefined set of numbers into the tree one by one, and checking if the tree is in the correct order")
    void Append() {
        for (int j : testArray) {
            UUT.Push(j);
            System.out.print(j + ", ");
        }
        
        assertTrue(UUT.isPQ(UUT.Root), "The heap is constructed incorrectly");
        System.out.println("\nDone Adding\n");
        
        for (int i = 0; i < testArray.length; i++) {
            int num = UUT.Pull();
            System.out.print(num + ", ");
            assertEquals( Result[i],num, "The heap is not in the correct order");
            assertTrue(UUT.isPQ(UUT.Root), "the function Pull is not working correctly");
        }
    }
    
    @Test
    @Tag("Basic Functionality")
    @DisplayName("Test pushing a predefined set of numbers into the tree and then checking if the tree is in the correct order")
    void AppendArray(){
        UUT.Push(testArray);
    
        System.out.println("Done Adding");

         for (int i = 0 ; i < testArray.length; i++) {
             int num = UUT.Pull();
             assertEquals(Result[i],num, "The heap is not in the correct order");
         }
    }
    
    @RepeatedTest(300)
    @Tag("Stress Test")
    @DisplayName("Test pushing a random set of numbers into the tree and then checking if the tree is in the correct order")
    void RandomAppendTest() {
        int[] RandomArray = ThreadLocalRandom.current().ints(0, Integer.MAX_VALUE).distinct().limit(20).toArray();
        Integer[] SortedArray = Arrays.stream(RandomArray).boxed().toArray(Integer[]::new);
        Arrays.sort(SortedArray, Collections.reverseOrder());
        
        for(int key : RandomArray)
            UUT.Push(key);

        assertTrue(UUT.isPQ(UUT.Root), "The heap is constructed incorrectly");
        System.out.println("\nDone Adding");

        for(int key : SortedArray){
            int num = UUT.Pull();
            assertAll(()-> {
                assertEquals(key, num, "The heap is not in the correct order");
                assertTrue(UUT.isPQ(UUT.Root), "the function Pull is not working correctly");
            });
        }
    }
    
    @Test
    @Tag("Stress Test")
    @DisplayName("Test that breaks")
    void TestThatBreaks() {
        int[] val = { 19, 21, 26, 68, 78, 3, 46, 82, 69, 77, 7, 51, 81, 83, 54, 65, 63, 9, 15, 99 };
        Integer[] SortedArray = Arrays.stream(val).boxed().toArray(Integer[]::new);
        Arrays.sort(SortedArray, Collections.reverseOrder());
        
        for(int key : val)
            UUT.Push(key);

        assertTrue(UUT.isPQ(UUT.Root), "The heap is constructed incorrectly");
        System.out.println("\nDone Adding");

        for(int key : SortedArray){
            int num = UUT.Pull();
            assertAll(()-> {
                assertEquals(key, num, "The heap is not in the correct order");
                assertTrue(UUT.isPQ(UUT.Root), "the function Pull is not working correctly");
            });
        }

    }
    
    @ParameterizedTest
    @ValueSource(ints = { 10, 100, 1000, 10000, 100000, 1000000 })
    @Timeout(value = 10)
    @Tag("Stress Test")
    @DisplayName("Large Scale Test")
    void LargeScaleTest(int size) {
        Integer[] SortedArray = new Integer[size];
        int[] RandomArray = ThreadLocalRandom.current().ints(0, Integer.MAX_VALUE).distinct().limit(size).toArray();
        for(int i = 0; i < size; i++){
            SortedArray[i] = RandomArray[i];
        }
        Arrays.sort(SortedArray, Collections.reverseOrder());
        System.out.println("Done generating random numbers");
    
        assertTimeout(Duration.ofSeconds(1), () -> {
            for (int i = 0; i < size; i++) {
                UUT.Push(RandomArray[i]);
            }
        }, "The heap must be built in less than 1 second");
    
        System.out.println("Added " + size + " numbers, took " + UUT.getDuration().toMillis() + " milliseconds, and performed " + UUT.getCounter()/size+ " comparisons");
        UUT.Reset();
        
        int num;
        for(int i = 0; i < size; i++) {
            num = UUT.Pull();
            assertEquals(SortedArray[i], num, "The heap is not in the correct order");
        }
    
        System.out.println("Pulled " + size + " numbers, took " + UUT.getDuration().toMillis() + " milliseconds, and performed " + UUT.getCounter()/size+ " comparisons");
        UUT.Reset();
    
        System.out.println();
        
    }
    
    @Test
    @Tag("Production")
    @DisplayName("Test adding the file data into the Queue")
    void RealWorldTest() throws IOException {
        FileOps DataFile = new FileOps("src/Files/keys_1000000_BE.bin");
    
        int[] InsertionKeys = DataFile.Read();
        Integer[] SortedArray = Arrays.stream(InsertionKeys).boxed().toArray(Integer[]::new);
        Arrays.sort(SortedArray, Collections.reverseOrder());
        
        for(int key : InsertionKeys)
            UUT.Push(key);
        
        assertTrue(UUT.isPQ(UUT.Root), "The Priority Queue is not constructed correctly");
        System.out.println("\nDone Adding");
        
        for(int i = 0 ; i < 100 ; i++) {
            int num = UUT.Pull();
            assertEquals(SortedArray[i], num, "The Priority Queue is not in the correct order");
            assertTrue(UUT.isPQ(UUT.Root), "the function Pull is not working correctly");
        }
    }
    
}