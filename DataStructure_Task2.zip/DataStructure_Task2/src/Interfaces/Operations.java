package src.Interfaces;

/**
 * This class contains the operations that must be available to the end-user..
 */
public interface Operations {
    
    /**
     * Adds the specified value into the tree.
     * @param value the value to add.
     */
    public void Push(int value);

}
