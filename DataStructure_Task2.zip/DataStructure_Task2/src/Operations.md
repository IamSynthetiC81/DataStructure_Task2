# Μέθοδοι Λειτουργικής Επεξεργασίας

## Operations
Οι μέθοδοι που υποστηρίζονται από το την διεπαφή [Operations](Interfaces/Operations.java) είναι:
 - **`Push(int value)`** - Προσθήκη νέου στοιχείου στον πίνακα.

## HeapOperations
Οι μέθοδοι που υποστηρίζονται από το την διεπαφή [HeapOperations](Interfaces/HeapOperations.java) είναι:
- **`Push(int[] values)`** - Προσθήκη στοιχείον στον πίνακα.
- **`Pull()`** - Επιστρέφει και αφαιρεί τον μέγιστο αριθμό απο τον πίνακα.
- **`Clear()`** - Αδειάζει τον πίνακα.

## BSTOperations

Οι μέθοδοι που υποστηρίζονται από το την διεπαφή [BSTOperations](Interfaces/BSTOperations.java) είναι:
- **`Search(int value)`** - Επιστρέφει τον κόμβο όπου βρίσκεται η τιμή.
- **`Pull(int value)`** - αφαιρεί τον αριθμό απο τον πίνακα.
- **`Clear()`** - Αδειάζει τον πίνακα.

Οι διεπαφές **`BSTOperations`** και **`HeapOperations`** επεκτείνουν την **`Operations`**. Οπότε
αρκεί να υλοποιήσουμε μία απο αυτές.